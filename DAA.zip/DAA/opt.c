#include<stdio.h>
#include<stdlib.h>

int noOfTapes;			//number of tapes
int sizeOfTapes;		//size of all tapes
int noOfProcess;		//no of process
int len_process[20] = {0};	//length of each process
int tapes[10][10];		
int flag = 0;
int cnt;
int size[20];			//ramaining size of each tape left

void merge(int len_process[20],int low,int mid,int high)
{
        int i,j = 0,temp[20];
        int lo = low;
        int mi = mid + 1;
        int hi = high;
        while(lo <= mid && mi <=high)
        {
                if(len_process[lo] <= len_process[mi])
                {
                        temp[j] = len_process[lo];
                        lo++;
                        j++;
                }
                else
                {
                        temp[j] = len_process[mi];
                        mi++;
                        j++;
                }
        }
        while(lo <= mid)
        {
                temp[j++] = len_process[lo++];
        }
        while(mi <= high)
        {
                temp[j++] = len_process[mi++];
        }
        for(i = low,j = 0;i <= high;i++,j++)
        {
                len_process[i] = temp[j];
        }
}

void partition(int len_process[20],int low,int high)
{
        int mid;
        if(low < high)
        {       
                mid = (low + high) / 2;
                partition(len_process,low,mid);
                partition(len_process,mid+1,high);
                merge(len_process,low,mid,high);
        }
}
int store(int len_process[20],int noOfProcess,int noOfTapes,int tapes[10][10])
{
        int tape_no;
        int i = 0;
        int k = -1;
        int j = 0;
        for(i = 0,j = 0;i < noOfProcess;i++,j++)
        {
        	tape_no = (i % noOfTapes);
        	if(size[tape_no] >= len_process[i])
        	{
		        if(tape_no == 0)
		        {           	
		                k++;
		                j = 0;
		        }
		        cnt++;
		        tapes[j][k] = len_process[i];
		        size[j] = size[j] - len_process[i];
		 }
		 else
		 {
		 	flag = 1;
		 }
        }
        return k;
}

int main()
{       
        int i = 0,j,count = -1;
        
        printf("Enter the no of tapes\n");
        scanf("%d",&noOfTapes);
        printf("Enter the size of tapes\n");
        scanf("%d",&sizeOfTapes);
        
        for(i = 0;i < noOfTapes;i++)
        {
        	size[i] = sizeOfTapes;
        }
        
        printf("Enter the no of process\n");
        scanf("%d",&noOfProcess);
        
        for(i = 0;i < noOfProcess;i++)
        {
                    printf("Enter the length of process %d\n",i);
                    scanf("%d",&len_process[i]);        
        }
        
        partition(len_process,0,noOfProcess-1);                //PARTITION
        
        int k = store(len_process,noOfProcess,noOfTapes,tapes);   //STORE
        
        i = 0;
        
        for(count = 0;count < noOfTapes;count++)
        {
        	printf("Tape %d\t - \t",count);
                for(j = 0;j<=k;j++)
                {
                        i++;
                        if(tapes[count][j] != 0)
                                printf("%d\t",tapes[count][j]);
                }
                printf("\n");
        }
        
        if(flag == 1)
        {
        	printf("Memory Full.Cannot store - \t");
        	for(i = cnt;i< noOfProcess;i++)
        	{
        		printf("%d\t",len_process[i]);
        	}
        	printf("\n");
        }
}

