#include<stdio.h>
#include<stdlib.h>

int *board,scnt=1;
void display(int n)
{
	int i,j;
	
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(board[i]==j)
			{
				printf("Q ");
			}
			else
			{
				printf("0 ");
			}
		}
		printf("\n");
	}
}

void NQueen(int k,int n)          //k=Queen no. & n=no. of queens
{
	int i;                   //i=column no
	
	for(i=1;i<=n;i++)
	{
		if(Place(k,i))
		{
			board[k] = i;
			if(k == n)
			{
				printf("\nSolution no: %d\n",scnt);
				display(n);
				scnt++;
			}
			else
			{
				NQueen(k+1,n);
			}
		}
	}
}

int Place(int k,int i)
{
	int j;
	
	for(j=1;j<=k-1;j++)
	{
		if((board[j] == i) || (abs(board[j]-i) == abs(j-k)))
		{
			return 0;
		}
	}
	return 1;
}

int main()
{
	int n=0,i,j;
	
	printf("Enter no. of queens for the problem:\n");
	scanf("%d",&n);
	
	if(n<4)
	{
		printf("There is no solution for n<4 queen problem\n");
		return 0;
	}
	
	board = (int*)malloc(n*sizeof(int));
	
	NQueen(1,n);
	
	for(i=1;i<=n;i++)
	{
		printf("%d" ,board[i]);
	}
	return 0;
}

