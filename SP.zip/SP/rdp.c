#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

char input[10];
int i,error;
void E();
void T();
void Eprime();
void Tprime();
void F();

int main()
{
    i=0;
    error=0;
    printf("enter arithmetic expression \n");
    gets(input);
    E();
    if(strlen(input)==i && error==0)
    printf("Accepted \n");
    else
    printf("rejected \n");
    return 0;
}

void E(){
    T();
    Eprime();
}

void T()
{
    F();
    Tprime();
}

void F()
{
    if(isalpha(input[i]))
    i++;
    else if (input[i]=='(')
    {
        i++;
        E();
        if (input[i]==')')
            i++;
        else
            error=1;
    }
    else
        error=1;

}


void Eprime()
{
    if(input[i]=='+')
    {
        i++;
        T();
        Eprime();
    }
}

void Tprime(){
    if(input[i]=='*')
    {
        i++;
        F();
        Tprime();
    }
}



//OUTPUT:

gcc rdp.c
rdp.c: In function ‘main’:
rdp.c:19:5: warning: ‘gets’ is deprecated (declared at /usr/include/stdio.h:638) [-Wdeprecated-declarations]
     gets(input);
     ^
/tmp/cc6NBTIM.o: In function `main':
rdp.c:(.text+0x28): warning: the `gets' function is dangerous and should not be used.
ashish@DELL-pc:~/Desktop/SP$ ./a.out
enter arithmetic expression 
a+(a*a)
Accepted 
ashish@DELL-pc:~/Desktop/SP$ ./a.out
enter arithmetic expression 
a++a
rejected 

